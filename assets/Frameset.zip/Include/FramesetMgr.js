// Constants: Frame names
CONTENT_FRAME = "frameContent";
HIDDEN_FRAME = "frameHidden";
NAVCLOSED_FRAME = "frameNavClosed";
NAVOPEN_FRAME = "frameNavOpen";
TITLE_FRAME = "frameTitle";
TOC_FRAME = "frameToc";
MAIN_FRAME = "frameLearnTask";
PARENTUI_FRAMESET = "framesetParentUI"

function FindFrmMgr(win)
{
   var frmDepthCount = 0;
   while ((win.g_frameMgr == null) && (win.parent != null) && (win.parent != win))
   {
      frmDepthCount++;
      
      if (frmDepthCount > 20) 
      {
         return null;
      }
      
      win = win.parent;
   }
   return win.g_frameMgr;
}


function API_GetFramesetManager()
{
    return FindFrmMgr(window);
}

function FramesetManager()
{
    // "public" api
    this.SetActivityId = FM_SetActivityId;  // Set the id of the current activity
    this.GetActivityId = FM_GetActivityId;  // Get the id of the current activity

    this.getDataActivity = FM_getDataActivity;
    this.commitData = FM_commitData;
    
    this.DoPrevious = FM_DoPrevious;
    this.DoNext = FM_DoNext;

    // "private" data for the object
    this.m_showNext = false;
    this.m_showPrevious = false;
    this.m_showAbandon = false;
    this.m_contentFrameUrl = null;  // url to load in content frame
    this.m_attemptId = "-1";
    this.m_activityId = "-1";

    this.toc = [];
    this.data = [];
    this.version = null;
    this.complete = false;
    
    this.m_log = new Log();
    this.DebugLog = FM_NoOp;

    // PREPARE DATA
    this.ds = localStorage.getItem("scorm");
    if(!this.ds) this.ds = "{}";
    this.ds = JSON.parse(this.ds);

    this.toc = this.ds["toc"];
    if(!this.toc) this.toc = [];
    this.data = this.ds["data"];
    this.m_activityId = this.ds["activity"];

    this.version = this.ds["version"];
    if(!this.version) this.version = "V1p3";	// Version of current session

    this.complete = this.ds["complete"];
    if(!this.complete) this.complete = false;	// Version of current session

    if(!this.data){
        this.data = [];
        for(var el of this.toc){
            this.data.push({id: el.id});
        }
    }

    if(!this.m_activityId){
        for(var el of this.toc){
            if(el.href != ""){
                this.m_activityId = el.id;
                break;
            }
        }
    }

    window.g_frameMgr = this;
}

function FM_getDataActivity()
{
    return this.data.filter((el) => el.id == this.m_activityId)[0];
}

function FM_commitData(){
    this.ds["data"] = this.data;
    this.ds["activity"] = this.m_activityId;
    this.ds["complete"] = this.complete;
    var str = JSON.stringify(this.ds);
    localStorage.setItem("scorm", str);
}

function FM_NoOp()
{
    // do nothing
}

function FM_DebugLog( strMessage )
{
    this.m_log.WriteMessage( strMessage );
}


function FM_SetActivityId ( strActivityId )
{
    this.DebugLog("SetActivityId: Begin. strActivityId = " + strActivityId);
    this.m_activityId = strActivityId;
}

function FM_GetActivityId ()
{
    return this.m_activityId;
}

function FM_DoPrevious(){
    var idx = this.toc.findIndex((el) => el.id == this.m_activityId);
    for(var i=idx - 1; i >=0; i--){
        if(this.toc[i].href !== ""){
            this.m_activityId = this.toc[i].id;
            window.top.document.getElementById(TOC_FRAME).src = "Toc.htm?r=" + Math.random() + "&ActivityId=" + this.m_activityId;
            break;
        }
    }
}

function FM_DoNext(){
    var idx = this.toc.findIndex((el) => el.id == this.m_activityId);
    for(var i=idx + 1; i < this.toc.length; i++){
        if(this.toc[i].href !== ""){
            this.m_activityId = this.toc[i].id;
            window.top.document.getElementById(TOC_FRAME).src = "Toc.htm?r=" + Math.random() + "&ActivityId=" + this.m_activityId;
            break;
        }
    }
}

/************** Log object **********************/
// Log implements a log of the frameMgr operations

function Log()
{
    this.WriteMessage = LOG_WriteMessage;
    this.GetConsole = LOG_GetConsole;
    
    this.m_console;
}

function LOG_WriteMessage( strMessage )
{
    var console = this.GetConsole();
    console.document.writeln("Message: " + strMessage + "<br>");
    console.document.writeln("-------------------------<br>");
}

function LOG_GetConsole()
{
    if ((this.m_console == null) || (this.m_console.closed))
    {
        this.m_console = window.open("", "console", "width=600,height=300,resizable,scrollbars=yes");
        this.m_console.document.open("text/plain");
    }
    return this.m_console;
}
